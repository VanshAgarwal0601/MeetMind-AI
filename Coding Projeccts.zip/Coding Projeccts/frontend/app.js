// MeetMind AI Client Logic

// Configuration details
const API_BASE = window.location.origin;
let mediaRecorder = null;
let audioChunks = [];
let recordInterval = null;
let recordSeconds = 0;
let isPaused = false;
let selectedAudioBlob = null;
let selectedFileName = "";
let currentAudioDuration = 0;
let meetingsHistory = [];
let speechUtterance = null;

// Page Initialization Logic
document.addEventListener('DOMContentLoaded', () => {
  const currentPath = window.location.pathname;

  if (currentPath === '/login') {
    checkLoggedInRedirect();
  } else if (currentPath === '/dashboard') {
    validateSession();
    initializeDashboard();
  }
});

// ==========================================
// 1. AUTHENTICATION & SESSION MANAGEMENT
// ==========================================

// Check if user is already authenticated
function checkLoggedInRedirect() {
  const token = localStorage.getItem('meetmind_token');
  if (token) {
    window.location.href = '/dashboard';
  }
}

// Ensure the user has a valid active token
function validateSession() {
  const token = localStorage.getItem('meetmind_token');
  if (!token) {
    window.location.href = '/login';
  }
}

// Login & Signup switching view states
let activeAuthTab = 'login';
function switchAuthTab(tab) {
  activeAuthTab = tab;
  const tabLogin = document.getElementById('tabLogin');
  const tabSignup = document.getElementById('tabSignup');
  const submitBtn = document.getElementById('submitBtn');
  const errorPanel = document.getElementById('authError');
  const successPanel = document.getElementById('authSuccess');

  errorPanel.style.display = 'none';
  successPanel.style.display = 'none';

  if (tab === 'login') {
    tabLogin.classList.add('active');
    tabSignup.classList.remove('active');
    submitBtn.textContent = 'Sign In';
  } else {
    tabLogin.classList.remove('active');
    tabSignup.classList.add('active');
    submitBtn.textContent = 'Sign Up';
  }
}

// Mock OAuth click event handler
function mockOAuth(provider) {
  const successPanel = document.getElementById('authSuccess');
  const errorPanel = document.getElementById('authError');
  
  errorPanel.style.display = 'none';
  successPanel.textContent = `Connecting to ${provider} secure OAuth tunnel...`;
  successPanel.style.display = 'block';
  
  setTimeout(() => {
    // Generate mock token and login
    localStorage.setItem('meetmind_token', 'mock_oauth_jwt_token_2026');
    localStorage.setItem('meetmind_user_email', `oauth.user@${provider.toLowerCase()}.com`);
    window.location.href = '/dashboard';
  }, 1000);
}

// Handle auth form submission
async function handleAuthSubmit(event) {
  event.preventDefault();
  
  const email = document.getElementById('emailInput').value.trim();
  const password = document.getElementById('passwordInput').value;
  const errorPanel = document.getElementById('authError');
  const successPanel = document.getElementById('authSuccess');
  const submitBtn = document.getElementById('submitBtn');

  errorPanel.style.display = 'none';
  successPanel.style.display = 'none';
  submitBtn.disabled = true;
  submitBtn.textContent = activeAuthTab === 'login' ? 'Authenticating...' : 'Registering...';

  const endpoint = activeAuthTab === 'login' ? '/api/auth/login' : '/api/auth/signup';

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Authentication connection failed.');
    }

    // Success: save token and user info
    localStorage.setItem('meetmind_token', data.token);
    localStorage.setItem('meetmind_user_email', data.user.email);

    successPanel.textContent = data.message || 'Access granted!';
    successPanel.style.display = 'block';

    setTimeout(() => {
      window.location.href = '/dashboard';
    }, 800);

  } catch (err) {
    errorPanel.textContent = err.message;
    errorPanel.style.display = 'block';
    submitBtn.disabled = false;
    submitBtn.textContent = activeAuthTab === 'login' ? 'Sign In' : 'Sign Up';
  }
}

// Logout user
function handleLogout() {
  // Cancel speech synthesis if reading
  window.speechSynthesis.cancel();
  localStorage.removeItem('meetmind_token');
  localStorage.removeItem('meetmind_user_email');
  window.location.href = '/';
}

// ==========================================
// 2. DASHBOARD VIEWPORT SWAPPING
// ==========================================

let activeDashboardTab = 'overview';
function initializeDashboard() {
  // Set User Details in Sidebar
  const email = localStorage.getItem('meetmind_user_email') || 'user@company.com';
  document.getElementById('userEmailFull').textContent = email;
  
  const prefix = email.split('@')[0];
  document.getElementById('userEmailPrefix').textContent = prefix.charAt(0).toUpperCase() + prefix.slice(1);
  document.getElementById('avatarLetter').textContent = prefix.charAt(0).toUpperCase();

  // Load meeting logs from database
  fetchMeetingsHistory();
}

function switchDashboardTab(tabId) {
  // Stop speaking
  window.speechSynthesis.cancel();
  
  // Set active sidebar item state
  const sidebarItems = document.querySelectorAll('.sidebar-item');
  sidebarItems.forEach(item => item.classList.remove('active'));
  
  // Highlight clicked
  const activeItemMap = {
    'overview': 0,
    'workspace': 1,
    'history': 2,
    'analytics': 3,
    'help': 4
  };
  sidebarItems[activeItemMap[tabId]].classList.add('active');

  // Switch display container
  const tabViews = document.querySelectorAll('.tab-view');
  tabViews.forEach(view => view.classList.remove('active'));
  document.getElementById(`tabView-${tabId}`).classList.add('active');

  // Customize layout titles
  const viewTitle = document.getElementById('viewTitle');
  const viewSubtitle = document.getElementById('viewSubtitle');
  const searchBar = document.getElementById('globalSearchBarContainer');

  searchBar.style.display = 'none';

  if (tabId === 'overview') {
    viewTitle.textContent = 'Workspace Overview';
    viewSubtitle.textContent = 'Summary statistics and entryways';
    updateOverviewMetrics();
  } else if (tabId === 'workspace') {
    viewTitle.textContent = 'MeetMind AI Workspace';
    viewSubtitle.textContent = 'Record live sessions or analyze audio files';
  } else if (tabId === 'history') {
    viewTitle.textContent = 'Processed Meeting History';
    viewSubtitle.textContent = 'List of analyzed logs with instant keyword filter';
    searchBar.style.display = 'block';
    renderHistoryTable();
  } else if (tabId === 'analytics') {
    viewTitle.textContent = 'Intelligence & Analytics';
    viewSubtitle.textContent = 'Meeting metrics and summaries';
    updateAnalyticsView();
  } else if (tabId === 'help') {
    viewTitle.textContent = 'Help & Platform FAQs';
    viewSubtitle.textContent = 'Frequently asked questions regarding processing and configurations';
  }

  activeDashboardTab = tabId;
}

// ==========================================
// 3. AUDIO RECORDING LOGIC (MediaRecorder)
// ==========================================

async function toggleRecording() {
  if (!mediaRecorder || mediaRecorder.state === 'inactive') {
    // START NEW RECORDING
    audioChunks = [];
    recordSeconds = 0;
    isPaused = false;
    selectedAudioBlob = null;
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Select appropriate options (WebM is highly compressed and supported across modern browsers)
      const options = { mimeType: 'audio/webm' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) {
        options.mimeType = 'audio/ogg';
        if (!MediaRecorder.isTypeSupported(options.mimeType)) {
          options.mimeType = ''; // Let browser pick default supported type
        }
      }

      mediaRecorder = new MediaRecorder(stream, options);
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
        selectedAudioBlob = audioBlob;
        selectedFileName = `LiveRecording_${new Date().toISOString().slice(0, 10)}.webm`;
        currentAudioDuration = recordSeconds;
        
        // Disable visual wave
        document.getElementById('recordVisualizer').classList.remove('recording', 'paused');
        document.getElementById('recordStatus').textContent = 'Recording stopped. Initializing AI analysis...';
        
        // Hide control elements
        document.getElementById('pauseRecordBtn').style.display = 'none';
        document.getElementById('stopRecordBtn').style.display = 'none';
        document.getElementById('recordTime').style.display = 'none';

        // Auto trigger server AI process API pipeline
        processMeetingAudio(selectedAudioBlob, selectedFileName, currentAudioDuration);
      };

      mediaRecorder.start(1000); // chunk bytes every second
      
      // Visual states
      document.getElementById('recordVisualizer').classList.add('recording');
      document.getElementById('recordStatus').textContent = 'Recording live...';
      document.getElementById('recordTime').style.display = 'block';
      document.getElementById('pauseRecordBtn').style.display = 'inline-flex';
      document.getElementById('stopRecordBtn').style.display = 'inline-flex';

      startRecordTimer();
    } catch (err) {
      console.error('[MediaRecorder] Microphone permissions error:', err);
      alert('Error accessing microphone: Please ensure browser audio recording permission is granted.');
    }
  }
}

function startRecordTimer() {
  clearInterval(recordInterval);
  recordInterval = setInterval(() => {
    if (!isPaused) {
      recordSeconds++;
      const mins = Math.floor(recordSeconds / 60).toString().padStart(2, '0');
      const secs = (recordSeconds % 60).toString().padStart(2, '0');
      document.getElementById('recordTime').textContent = `${mins}:${secs}`;
    }
  }, 1000);
}

function pauseRecording() {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.pause();
    isPaused = true;
    document.getElementById('recordVisualizer').classList.remove('recording');
    document.getElementById('recordVisualizer').classList.add('paused');
    document.getElementById('recordStatus').textContent = 'Recording paused';
    document.getElementById('pauseRecordBtn').textContent = 'Resume';
  } else if (mediaRecorder && mediaRecorder.state === 'paused') {
    mediaRecorder.resume();
    isPaused = false;
    document.getElementById('recordVisualizer').classList.remove('paused');
    document.getElementById('recordVisualizer').classList.add('recording');
    document.getElementById('recordStatus').textContent = 'Recording live...';
    document.getElementById('pauseRecordBtn').textContent = 'Pause';
  }
}

function stopRecording() {
  if (mediaRecorder && (mediaRecorder.state === 'recording' || mediaRecorder.state === 'paused')) {
    clearInterval(recordInterval);
    // Stop tracks to release microphone hardware locks
    mediaRecorder.stream.getTracks().forEach(track => track.stop());
    mediaRecorder.stop();
  }
}

// ==========================================
// 4. AUDIO FILE UPLOAD (Drag and Drop)
// ==========================================

function triggerFileInput() {
  document.getElementById('fileInput').click();
}

function handleDragOver(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.add('dragover');
}

function handleDragLeave() {
  document.getElementById('dropZone').classList.remove('dragover');
}

function handleDrop(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.remove('dragover');
  
  if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
    const file = e.dataTransfer.files[0];
    validateAndSelectFile(file);
  }
}

function handleFileSelect(e) {
  if (e.target.files && e.target.files.length > 0) {
    const file = e.target.files[0];
    validateAndSelectFile(file);
  }
}

function validateAndSelectFile(file) {
  // Enforce size limit 25MB
  if (file.size > 25 * 1024 * 1024) {
    alert('File size exceeds the 25MB limit. Please upload a smaller audio clip.');
    return;
  }

  // Ensure it's an audio file
  if (!file.type.startsWith('audio/')) {
    alert('Invalid file format. Please upload a standard audio file (MP3, WAV, M4A, WEBM).');
    return;
  }

  selectedAudioBlob = file;
  selectedFileName = file.name;
  
  // Calculate mock duration (1.5 min per MB as an estimate)
  currentAudioDuration = Math.round((file.size / (128 * 1024)) || 60);

  const detailDiv = document.getElementById('fileSelectionDetails');
  detailDiv.textContent = `Selected: ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB). Starting AI process...`;
  detailDiv.style.display = 'block';

  // Automatically start process API pipeline
  processMeetingAudio(selectedAudioBlob, selectedFileName, currentAudioDuration);
}

// ==========================================
// 5. ASYNC API PIPELINE CALL (Process audio)
// ==========================================

async function processMeetingAudio(audioBlob, fileName, durationSeconds) {
  // View states: show loader, hide content & placeholder
  const placeholder = document.getElementById('resultsPlaceholder');
  const loader = document.getElementById('processingLoader');
  const content = document.getElementById('resultsContent');

  placeholder.style.display = 'none';
  loader.style.display = 'flex';
  content.style.display = 'none';

  // Bundle audio blob in FormData object
  const formData = new FormData();
  formData.append('audio', audioBlob, fileName);
  formData.append('title', fileName.replace(/\.[^/.]+$/, "").replace(/_/g, " ")); // clean name for title
  formData.append('duration', durationSeconds);

  const token = localStorage.getItem('meetmind_token');

  try {
    const response = await fetch(`${API_BASE}/api/process-audio`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });

    const meetingData = await response.json();

    if (!response.ok) {
      throw new Error(meetingData.error || 'Server pipeline processing error occurred.');
    }

    // Success: Render results onto panel
    renderAIResults(meetingData);
    
    // Add meeting to top of historical state array
    meetingsHistory.unshift(meetingData);
    
    // Clear file uploads labels
    document.getElementById('fileSelectionDetails').style.display = 'none';
    document.getElementById('fileSelectionDetails').textContent = '';

  } catch (err) {
    console.error('[MeetMind Client API Error]:', err);
    alert(`Processing failed: ${err.message}`);
    placeholder.style.display = 'flex';
  } finally {
    loader.style.display = 'none';
  }
}

// ==========================================
// 6. DOM RENDER & DETAILS DISPATCH
// ==========================================

function renderAIResults(meeting) {
  // Display result panel
  document.getElementById('resultsPlaceholder').style.display = 'none';
  document.getElementById('resultsContent').style.display = 'flex';

  // Header Title
  document.getElementById('resultMeetingTitle').textContent = meeting.title;

  // 6.1 Summaries
  document.getElementById('resultSummaryText').textContent = meeting.summary;

  // 6.2 Multi-speaker Diarized Transcripts
  const transcriptDiv = document.getElementById('resultTranscriptContainer');
  transcriptDiv.innerHTML = '';
  
  // Style each speaker block neatly
  const lines = meeting.transcript.split('\n');
  lines.forEach(line => {
    if (line.trim()) {
      const match = line.match(/^([^:]+):(.*)$/);
      if (match) {
        const speaker = match[1].trim();
        const speech = match[2].trim();
        
        const dialogBlock = document.createElement('div');
        dialogBlock.style.marginBottom = '0.75rem';
        dialogBlock.innerHTML = `<strong style="color: var(--primary-light);">${speaker}:</strong> <span>${speech}</span>`;
        transcriptDiv.appendChild(dialogBlock);
      } else {
        const textBlock = document.createElement('div');
        textBlock.style.marginBottom = '0.5rem';
        textBlock.textContent = line;
        transcriptDiv.appendChild(textBlock);
      }
    }
  });

  // 6.3 Action Items with Name Tag assignees
  const actionsDiv = document.getElementById('resultActionItemsContainer');
  actionsDiv.innerHTML = '';

  if (meeting.actionItems && meeting.actionItems.length > 0) {
    meeting.actionItems.forEach((item, index) => {
      const row = document.createElement('div');
      row.className = 'action-item-row';
      row.innerHTML = `
        <input type="checkbox" id="chk-${meeting._id}-${index}" class="action-checkbox" onchange="toggleActionCheckbox(this)">
        <div class="action-text">
          <span class="action-assignee">${item.name}</span>
          <span>${item.task}</span>
        </div>
      `;
      actionsDiv.appendChild(row);
    });
  } else {
    actionsDiv.innerHTML = '<p style="color: var(--text-muted);">No action items extracted.</p>';
  }

  // 6.4 Decisions List
  const decisionsList = document.getElementById('resultDecisionsList');
  decisionsList.innerHTML = '';
  if (meeting.decisions && meeting.decisions.length > 0) {
    meeting.decisions.forEach(decision => {
      const li = document.createElement('li');
      li.textContent = decision;
      decisionsList.appendChild(li);
    });
  } else {
    decisionsList.innerHTML = '<li style="background: transparent; border: none; padding-left: 0; color: var(--text-muted);">No decisions logged.</li>';
  }

  // 6.5 Review Questions List
  const questionsList = document.getElementById('resultQuestionsList');
  questionsList.innerHTML = '';
  if (meeting.reviewQuestions && meeting.reviewQuestions.length > 0) {
    meeting.reviewQuestions.forEach(question => {
      const li = document.createElement('li');
      li.textContent = question;
      questionsList.appendChild(li);
    });
  } else {
    questionsList.innerHTML = '<li style="background: transparent; border: none; padding-left: 0; color: var(--text-muted);">No review questions generated.</li>';
  }

  // Reset recorder input label
  document.getElementById('recordStatus').textContent = 'Ready to record';
}

// Checkbox item toggles custom visual strikethrough logic
function toggleActionCheckbox(checkbox) {
  const textSpan = checkbox.nextElementSibling.querySelector('span:last-child');
  if (checkbox.checked) {
    textSpan.style.textDecoration = 'line-through';
    textSpan.style.color = 'var(--text-muted)';
  } else {
    textSpan.style.textDecoration = 'none';
    textSpan.style.color = 'inherit';
  }
}

// View an old meeting details in the workspace tab
function viewMeetingDetails(meetingId) {
  const meeting = meetingsHistory.find(m => m._id === meetingId);
  if (meeting) {
    switchDashboardTab('workspace');
    renderAIResults(meeting);
  }
}

// ==========================================
// 7. GET MEETING HISTORY & SEARCH FILTER
// ==========================================

// Fetch meetings history list
async function fetchMeetingsHistory() {
  const token = localStorage.getItem('meetmind_token');
  try {
    const response = await fetch(`${API_BASE}/api/meetings`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (response.ok) {
      meetingsHistory = await response.json();
      updateOverviewMetrics();
    }
  } catch (error) {
    console.error('[MeetMind Client] Error fetching historical meetings:', error);
  }
}

// Render historical meetings table view
function renderHistoryTable(filteredList = null) {
  const listToRender = filteredList || meetingsHistory;
  const tbody = document.getElementById('historyTableBody');
  tbody.innerHTML = '';

  if (listToRender.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 3rem;">
          No matching meeting logs found.
        </td>
      </tr>
    `;
    return;
  }

  listToRender.forEach(m => {
    const dateStr = new Date(m.timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Format duration helper
    const durationStr = m.duration >= 60 
      ? `${Math.floor(m.duration / 60)}m ${m.duration % 60}s`
      : `${m.duration}s`;

    const actionCount = m.actionItems ? m.actionItems.length : 0;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="font-weight: 600; color: #fff;">${m.title}</td>
      <td>${dateStr}</td>
      <td style="font-family: monospace;">${durationStr}</td>
      <td>
        <span class="action-assignee" style="background: rgba(99, 102, 241, 0.1); border-color: rgba(99, 102, 241, 0.2);">${actionCount} Items</span>
      </td>
      <td>
        <button class="row-action-btn" onclick="viewMeetingDetails('${m._id}')">
          View Details
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Real-time client-side filter
function filterMeetingHistory() {
  const query = document.getElementById('meetingSearchInput').value.toLowerCase().trim();
  
  if (query === "") {
    renderHistoryTable(meetingsHistory);
    return;
  }

  const filtered = meetingsHistory.filter(m => {
    const titleMatch = m.title.toLowerCase().includes(query);
    const transcriptMatch = m.transcript.toLowerCase().includes(query);
    const summaryMatch = m.summary.toLowerCase().includes(query);
    const assigneeMatch = m.actionItems && m.actionItems.some(item => item.name.toLowerCase().includes(query) || item.task.toLowerCase().includes(query));
    
    return titleMatch || transcriptMatch || summaryMatch || assigneeMatch;
  });

  renderHistoryTable(filtered);
}

// ==========================================
// 8. TEXT-TO-SPEECH (SpeechSynthesis)
// ==========================================

function speakSummary() {
  const summaryText = document.getElementById('resultSummaryText').textContent;
  
  if (!summaryText) return;

  // If already speaking, cancel/stop it (toggles off)
  if (window.speechSynthesis.speaking) {
    window.speechSynthesis.cancel();
    return;
  }

  speechUtterance = new SpeechSynthesisUtterance(summaryText);
  
  // Set clean styling
  speechUtterance.rate = 1.0;
  speechUtterance.pitch = 1.0;
  
  // Load standard premium voices if available (Google US English, Safari Daniel, etc.)
  const voices = window.speechSynthesis.getVoices();
  const preferredVoice = voices.find(voice => voice.name.includes('Google') || voice.name.includes('Natural')) || voices[0];
  if (preferredVoice) {
    speechUtterance.voice = preferredVoice;
  }

  window.speechSynthesis.speak(speechUtterance);
}

// ==========================================
// 9. METRICS & ANALYTICS UPDATES
// ==========================================

function updateOverviewMetrics() {
  const totalMeetings = meetingsHistory.length;
  
  // Hours saved = meetings * 1.5 hours + total duration saved
  let totalDurationSeconds = meetingsHistory.reduce((acc, m) => acc + (m.duration || 0), 0);
  // Assume each processed meeting saves roughly 45 mins of manual summarization
  let hoursSaved = (totalMeetings * 0.75) + (totalDurationSeconds / 3600);

  // Total Action Items
  let totalActions = meetingsHistory.reduce((acc, m) => acc + (m.actionItems ? m.actionItems.length : 0), 0);

  // Inject into DOM
  const totalMeetingsEl = document.getElementById('metricTotalMeetings');
  const hoursSavedEl = document.getElementById('metricHoursSaved');
  const totalActionsEl = document.getElementById('metricTotalActions');

  if (totalMeetingsEl) totalMeetingsEl.textContent = totalMeetings;
  if (hoursSavedEl) hoursSavedEl.textContent = hoursSaved.toFixed(1);
  if (totalActionsEl) totalActionsEl.textContent = totalActions;
}

function updateAnalyticsView() {
  // Aggregate decisions
  let totalDecisions = meetingsHistory.reduce((acc, m) => acc + (m.decisions ? m.decisions.length : 0), 0);
  document.getElementById('analyticTotalDecisions').textContent = totalDecisions;

  // Average Duration
  let totalDurationSeconds = meetingsHistory.reduce((acc, m) => acc + (m.duration || 0), 0);
  let avgSeconds = meetingsHistory.length > 0 ? (totalDurationSeconds / meetingsHistory.length) : 0;
  let avgMins = Math.round(avgSeconds / 60);
  document.getElementById('analyticAvgDuration').textContent = `${avgMins} min`;
}
