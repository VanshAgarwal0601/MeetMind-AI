require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const { GoogleGenAI } = require('@google/genai');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'meetmind_ai_super_secure_secret_key_2026';

// CORS and Parsers Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend assets
app.use(express.static(path.join(__dirname, '../frontend')));

// Pretty console logging middleware
app.use((req, res, next) => {
  console.log(`[MeetMind Server] ${req.method} ${req.url}`);
  next();
});

// Configure Multer for processing file/blob uploads in memory
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB max size
});

// Setup Friendly Page Routing (removes need for .html extensions in URL)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/login.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dashboard.html'));
});

// Authentication Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication token is missing. Please sign in.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Your session has expired or is invalid. Please sign in again.' });
    }
    req.user = user;
    next();
  });
}

// Auth API Endpoint: Sign Up
app.post('/api/auth/signup', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Please provide both email and password.' });
  }

  try {
    const existingUser = await db.findUserByEmail(email);
    if (existingUser) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const savedUser = await db.saveUser({ email, passwordHash });
    
    // Auto-generate token to login user immediately
    const token = jwt.sign({ userId: savedUser._id, email: savedUser.email }, JWT_SECRET, { expiresIn: '7d' });
    
    res.status(201).json({
      message: 'Account created successfully.',
      token,
      user: { id: savedUser._id, email: savedUser.email }
    });
  } catch (error) {
    console.error('[MeetMind Auth] Signup Error:', error);
    res.status(500).json({ error: 'An unexpected database error occurred during signup.' });
  }
});

// Auth API Endpoint: Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Please provide both email and password.' });
  }

  try {
    const user = await db.findUserByEmail(email);
    if (!user) {
      return res.status(400).json({ error: 'Incorrect email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(400).json({ error: 'Incorrect email or password.' });
    }

    const token = jwt.sign({ userId: user._id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });

    res.json({
      message: 'Successfully authenticated.',
      token,
      user: { id: user._id, email: user.email }
    });
  } catch (error) {
    console.error('[MeetMind Auth] Login Error:', error);
    res.status(500).json({ error: 'An unexpected database error occurred during login.' });
  }
});

// Get User Meeting History
app.get('/api/meetings', authenticateToken, async (req, res) => {
  try {
    const meetings = await db.getMeetingsByUserId(req.user.userId);
    res.json(meetings);
  } catch (error) {
    console.error('[MeetMind API] Get Meetings Error:', error);
    res.status(500).json({ error: 'Failed to retrieve meeting history.' });
  }
});

// Process Meeting Audio Endpoint
app.post('/api/process-audio', authenticateToken, upload.single('audio'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No audio file uploaded. Please upload a file or record a audio clip.' });
  }

  const title = req.body.title || `Meeting on ${new Date().toLocaleDateString()}`;
  const duration = parseFloat(req.body.duration || 0);
  const geminiApiKey = process.env.GEMINI_API_KEY;

  console.log(`[MeetMind AI] Received audio upload: ${req.file.originalname} (${req.file.size} bytes), Mimetype: ${req.file.mimetype}`);

  let aiResponseJSON;

  if (!geminiApiKey) {
    // FALLBACK: If GEMINI_API_KEY is not defined, return a high-fidelity mockup to demonstrate full client-side interface capabilities
    console.warn('\x1b[33m%s\x1b[0m', '[MeetMind AI] Warning: GEMINI_API_KEY is missing. Using local mock processor fallback.');
    
    // Simulate API processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    aiResponseJSON = {
      transcript: `Speaker 1 (Project Manager): Good morning everyone, let's jump straight into the weekly sprint alignment. Sarah, can you start us off with the core API migration and DB architecture?
Speaker 2 (Lead Engineer): Sure! The PostgreSQL database schemas are fully migrated to production. I've deployed the server middleware endpoints to the staging cluster. The main bottleneck right now is resolving the CORS credentials issue on the login API. I'll need David's help to align the origin configs.
Speaker 3 (DevOps Specialist): Happy to jump in, Sarah. Let's block out 30 minutes right after this sync. I'll make sure the load balancer handles the routing headers.
Speaker 1 (Project Manager): Perfect, thanks David. What about client-side routing and layout polish?
Speaker 4 (UI Designer): I have finalized the responsive dark-mode styling and tested the media recording workflow. I'll document the API schema and push the HTML updates to main tonight.
Speaker 1 (Project Manager): Awesome work team. Let's sync on Slack once the CORS issue is resolved.`,
      summary: "The project team aligned on sprint deliverables, focusing on the API and database migration. Database schema upgrades are complete, and staging endpoints are deployed. The team identified a current blocking issue with CORS configurations on the login endpoints, which Sarah and David will resolve today. Frontend updates to the dashboard and custom responsive UI layout will be pushed by tonight.",
      actionItems: [
        { name: "Sarah & David", task: "Debug and resolve the API CORS credential issues on staging by today." },
        { name: "David", task: "Configure routing headers on the load balancer to support cross-origin requests." },
        { name: "Sarah", task: "Complete the post-deployment staging checks for API endpoints." },
        { name: "Lisa (UI)", task: "Push finalized dark slate theme stylesheets and MediaRecorder components to main branch by tonight." }
      ],
      decisions: [
        { text: "Approved using PostgreSQL as the persistent database solution for production deployments." },
        { text: "Agreed to run integration testing on staging cluster before release to public main branch." }
      ],
      reviewQuestions: [
        "What are the specific origin URLs allowed under the updated CORS middleware policies?",
        "Have the unit tests for User JWT registration and session token issuance been executed?",
        "What is the schedule for releasing frontend assets to production hosting environment?"
      ]
    };
  } else {
    // ACTUAL GEMINI INTEGRATION
    try {
      const ai = new GoogleGenAI({ apiKey: geminiApiKey });
      const base64Audio = req.file.buffer.toString('base64');
      const audioMimetype = req.file.mimetype || 'audio/webm';

      console.log(`[MeetMind AI] Calling Gemini API (gemini-2.5-flash) with base64 audio payload (${base64Audio.length} chars)...`);

      const prompt = `Analyze the provided meeting audio. Your tasks are:
1. Generate a multi-speaker transcript, trying to separate speakers as "Speaker 1 (Title/Role)", "Speaker 2", etc. using audio tone and voice indicators.
2. Provide a concise, high-level summary of the meeting.
3. Extract actionable items showing who (name) is assigned to which task.
4. Extract key decisions made during the discussion.
5. Create follow-up questions to review the status of progress.

Enforce the output strictly as a JSON object matching the defined schema.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            inlineData: {
              data: base64Audio,
              mimeType: audioMimetype
            }
          },
          prompt
        ],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'object',
            properties: {
              transcript: {
                type: 'string',
                description: 'Diarized transcript of the meeting audio highlighting speakers and their dialogue.'
              },
              summary: {
                type: 'string',
                description: 'A concise summary of the key meeting topics, discussions, and outcomes.'
              },
              actionItems: {
                type: 'array',
                description: 'List of specific tasks assigned to team members.',
                items: {
                  type: 'object',
                  properties: {
                    name: { type: 'string', description: 'Name of the person or team assigned to the action item.' },
                    task: { type: 'string', description: 'Detailed description of the task.' }
                  },
                  required: ['name', 'task']
                }
              },
              decisions: {
                type: 'array',
                description: 'Key decisions finalized or agreed upon by participants.',
                items: { type: 'string' }
              },
              reviewQuestions: {
                type: 'array',
                description: 'Unresolved queries or questions generated to verify follow-up status.',
                items: { type: 'string' }
              }
            },
            required: ['transcript', 'summary', 'actionItems', 'decisions', 'reviewQuestions']
          }
        }
      });

      const responseText = response.text();
      console.log('[MeetMind AI] Gemini Raw Response:', responseText);

      aiResponseJSON = JSON.parse(responseText);
    } catch (error) {
      console.error('[MeetMind AI] Gemini API Execution Failure:', error);
      return res.status(500).json({
        error: 'Failed to process audio with Gemini AI. Ensure the file is valid and API limits are not exceeded.',
        details: error.message
      });
    }
  }

  try {
    // Format decisions field to make sure it matches database schema format
    const formattedDecisions = Array.isArray(aiResponseJSON.decisions) 
      ? aiResponseJSON.decisions.map(d => typeof d === 'object' && d.text ? d.text : String(d))
      : [];

    const meetingPayload = {
      userId: req.user.userId,
      title: title,
      transcript: aiResponseJSON.transcript,
      summary: aiResponseJSON.summary,
      actionItems: aiResponseJSON.actionItems,
      decisions: formattedDecisions,
      reviewQuestions: aiResponseJSON.reviewQuestions,
      duration: duration
    };

    const savedMeeting = await db.saveMeeting(meetingPayload);
    res.json(savedMeeting);
  } catch (error) {
    console.error('[MeetMind API] Failed to save meeting results to DB:', error);
    res.status(500).json({ error: 'Audio processed successfully but saving meeting to historical database failed.' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    database: db.isMongoConnected() ? 'mongodb' : 'local_json_fallback',
    time: new Date().toISOString()
  });
});

// Run server and connect to database
db.connectDb().then(() => {
  app.listen(PORT, () => {
    console.log(`==================================================`);
    console.log(` MeetMind AI Server running at http://localhost:${PORT}`);
    console.log(` Serving frontend static assets from /frontend`);
    console.log(` Database: ${db.isMongoConnected() ? 'MongoDB (Mongoose)' : 'Local database.json Fallback'}`);
    console.log(`==================================================`);
  });
});
