const mongoose = require('mongoose');
const fs = require('fs').promises;
const path = require('path');

const LOCAL_DB_PATH = path.join(__dirname, '../database.json');
let isMongoConnected = false;

// Initialize MongoDB connection
async function connectDb() {
  const mongoUri = process.env.MONGO_URI;
  if (!mongoUri) {
    console.warn('\x1b[33m%s\x1b[0m', '[MeetMind DB] Warning: MONGO_URI environment variable not set. Falling back to local file storage.');
    await initLocalDb();
    return false;
  }

  try {
    // Attempt Mongoose connection with a short timeout so fallback happens quickly
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 3000
    });
    isMongoConnected = true;
    console.log('\x1b[32m%s\x1b[0m', '[MeetMind DB] Connected to MongoDB via Mongoose successfully.');
    return true;
  } catch (error) {
    console.error('\x1b[31m%s\x1b[0m', `[MeetMind DB] Mongoose connection error: ${error.message}`);
    console.warn('\x1b[33m%s\x1b[0m', '[MeetMind DB] Falling back to local JSON database storage.');
    await initLocalDb();
    return false;
  }
}

// Local Database Helpers
async function initLocalDb() {
  try {
    await fs.access(LOCAL_DB_PATH);
  } catch {
    // File doesn't exist, create it with default structure
    const initialDb = { users: [], meetings: [] };
    await fs.writeFile(LOCAL_DB_PATH, JSON.stringify(initialDb, null, 2), 'utf-8');
    console.log('[MeetMind DB] Local database file initialized at:', LOCAL_DB_PATH);
  }
}

async function readLocalDb() {
  try {
    const data = await fs.readFile(LOCAL_DB_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('[MeetMind DB] Error reading local database:', error.message);
    return { users: [], meetings: [] };
  }
}

async function writeLocalDb(dbData) {
  try {
    await fs.writeFile(LOCAL_DB_PATH, JSON.stringify(dbData, null, 2), 'utf-8');
  } catch (error) {
    console.error('[MeetMind DB] Error writing local database:', error.message);
  }
}

// Database Actions
async function saveUser(userData) {
  if (isMongoConnected) {
    const User = require('./models').User;
    const user = new User(userData);
    const saved = await user.save();
    return saved.toObject();
  } else {
    const db = await readLocalDb();
    const newUser = {
      _id: 'usr_' + Math.random().toString(36).substr(2, 9),
      email: userData.email.toLowerCase().trim(),
      passwordHash: userData.passwordHash,
      createdAt: new Date().toISOString()
    };
    db.users.push(newUser);
    await writeLocalDb(db);
    return newUser;
  }
}

async function findUserByEmail(email) {
  const searchEmail = email.toLowerCase().trim();
  if (isMongoConnected) {
    const User = require('./models').User;
    const user = await User.findOne({ email: searchEmail });
    return user ? user.toObject() : null;
  } else {
    const db = await readLocalDb();
    const user = db.users.find(u => u.email === searchEmail);
    return user || null;
  }
}

async function findUserById(id) {
  if (isMongoConnected) {
    const User = require('./models').User;
    const user = await User.findById(id);
    return user ? user.toObject() : null;
  } else {
    const db = await readLocalDb();
    const user = db.users.find(u => u._id === id);
    return user || null;
  }
}

async function saveMeeting(meetingData) {
  if (isMongoConnected) {
    const Meeting = require('./models').Meeting;
    const meeting = new Meeting(meetingData);
    const saved = await meeting.save();
    return saved.toObject();
  } else {
    const db = await readLocalDb();
    const newMeeting = {
      _id: 'mtg_' + Math.random().toString(36).substr(2, 9),
      userId: meetingData.userId,
      title: meetingData.title || `Meeting on ${new Date().toLocaleDateString()}`,
      transcript: meetingData.transcript,
      summary: meetingData.summary,
      actionItems: meetingData.actionItems || [],
      decisions: meetingData.decisions || [],
      reviewQuestions: meetingData.reviewQuestions || [],
      duration: meetingData.duration || 0,
      timestamp: new Date().toISOString()
    };
    db.meetings.push(newMeeting);
    await writeLocalDb(db);
    return newMeeting;
  }
}

async function getMeetingsByUserId(userId) {
  if (isMongoConnected) {
    const Meeting = require('./models').Meeting;
    const meetings = await Meeting.find({ userId }).sort({ timestamp: -1 });
    return meetings.map(m => m.toObject());
  } else {
    const db = await readLocalDb();
    const meetings = db.meetings
      .filter(m => m.userId === userId)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    return meetings;
  }
}

module.exports = {
  connectDb,
  saveUser,
  findUserByEmail,
  findUserById,
  saveMeeting,
  getMeetingsByUserId,
  isMongoConnected: () => isMongoConnected
};
