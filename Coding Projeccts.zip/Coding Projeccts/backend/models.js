const mongoose = require('mongoose');

// User Schema Definition
const UserSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  passwordHash: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Meeting Schema Definition
const MeetingSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  transcript: {
    type: String,
    required: true
  },
  summary: {
    type: String,
    required: true
  },
  actionItems: [
    {
      name: {
        type: String,
        required: true
      },
      task: {
        type: String,
        required: true
      }
    }
  ],
  decisions: [
    {
      type: String
    }
  ],
  reviewQuestions: [
    {
      type: String
    }
  ],
  duration: {
    type: Number,
    default: 0
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

const User = mongoose.model('User', UserSchema);
const Meeting = mongoose.model('Meeting', MeetingSchema);

module.exports = {
  User,
  Meeting
};
